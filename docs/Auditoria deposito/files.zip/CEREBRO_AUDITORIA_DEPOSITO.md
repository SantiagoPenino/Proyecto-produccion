# 🧠 CEREBRO — Auditoría de Depósito / Control Físico

> **Leer SIEMPRE antes de tocar código.** Actualizar SIEMPRE después de cambiar algo.
> Última actualización: 2026-08-17 · Fuente: screenshot de UI (⚠️ código fuente aún NO revisado)

---

## 1. Qué es este sistema

Módulo de **auditoría física de paquetería** (courier / depósito de encomiendas).
No es inventario por SKU: cada unidad es una **orden única** identificada por código
(`EUV-15265`, `DF-250`) asociada a un cliente.

**Objetivo del módulo:** cruzar lo que hay *físicamente* en el depósito contra lo que
dice la base de datos, usando pistola láser o cámara del móvil.

---

## 2. Estado actual observado (según UI)

### Tabs / contadores
| Tab | Valor visto | Qué significa | ⚠️ Observación |
|---|---|---|---|
| Escaneo Físico | 0 | Órdenes escaneadas en la sesión | Arranca en 0, OK |
| Órdenes Activas | 850 | Deberían estar en depósito | Universo a auditar |
| Caducadas | 171 | Superaron plazo de permanencia | ¿Están dentro de las 850? **CONFIRMAR** |
| Extraviadas | 850 | — | 🔴 **BUG: igual a Activas.** Ver §4.1 |
| Sobrantes | 0 | Físico sin respaldo en DB | OK |
| Entregadas Sin Pago | 10599 | Deuda de clientes | 🟠 No pertenece a auditoría física. Ver §4.6 |

### Paneles de la vista "Escaneo Físico"
1. **Pistola Escáner** — input de captura + botón cámara móvil + `Finalizar / Reporte`.
   Texto UI: *"Tus escaneos se guardan en la DB automáticamente."*
2. **Faltan por Escanear** — activas NO escaneadas. *"¿Ya se entregaron Físicamente?"*
3. **Entregada Errónea** — escaneadas pero figuran como Entregadas → deben volver a depósito.
4. **Falta Por Ingresar** — escaneadas que no existen en la DB.

### Matriz de reconciliación (está bien cubierta ✅)
|  | En sistema | No en sistema |
|---|---|---|
| **Escaneado** | Verificada / Entregada Errónea | Falta Por Ingresar |
| **No escaneado** | Faltan por Escanear | — (invisible) |

---

## 3. Reglas de negocio que NO se deben romper

- Un escaneo **nunca** debe borrar o pisar el estado original de la orden sin dejar traza.
- "Entregada Errónea" implica **revertir** el estado a "en depósito", no crear una orden nueva.
- Una orden escaneada dos veces **no** debe contar doble.
- El operador **no debe ver** el estado esperado antes de escanear (conteo ciego).
- Nada se marca como Extraviada sin pasar por reconteo.

---

## 4. Problemas detectados y solución propuesta

### 4.1 🔴 CRÍTICO — "Extraviadas" arranca en 850
**Síntoma:** Extraviadas == Órdenes Activas antes de escanear nada.
**Causa probable:** el contador se calcula como `activas - escaneadas` en vivo.
**Fix:** Extraviada solo se materializa al cerrar la sesión (`Finalizar / Reporte`) y
después del reconteo. Durante la sesión el estado correcto es *"pendiente de escaneo"*.
**Riesgo si se toca:** verificar que ningún reporte externo ya consuma ese contador.

### 4.2 🔴 Falta corte documental (snapshot)
La auditoría dura horas; entran y salen paquetes en el medio → falsos faltantes/sobrantes.
**Fix:** al iniciar sesión guardar `snapshot_ordenes_activas` con timestamp. Comparar
contra el snapshot, no contra la tabla viva. Movimientos posteriores → bandeja
"Movidos durante auditoría".

### 4.3 🟠 No hay reconteo
**Fix:** estado intermedio `PENDIENTE_RECONTEO`. Segunda pasada (idealmente otro operador)
antes de habilitar el cierre.

### 4.4 🟠 Sin causa ni responsable en la diferencia
**Fix:** al cerrar, cada faltante exige `motivo` (entregado sin escanear / error de carga /
rotura / no hallado / robo) + `usuario` + `fecha`. Sin motivo no se cierra.

### 4.5 🟠 Sin sesiones, operador ni zonas
**Fix:** entidad `sesion_auditoria` (id, operador, inicio, fin, zona, estado).
Permitir auditar por zona/estante. Sesión reanudable si se cae el navegador.

### 4.6 🟠 "Entregadas Sin Pago" (10599) mezclado con auditoría
Es cobranza, no control físico. Arrastra histórico sin filtro.
**Fix:** módulo aparte o, mínimo, aging (0-30 / 31-60 / 61-90 / +90 días) + monto.

### 4.7 🟡 Escaneo duplicado
**Fix:** detectar y avisar con feedback sonoro/visual distinto. No sumar.

### 4.8 🟡 Sin métricas de cierre
**Fix en el reporte:** ERI (verificadas/activas), faltantes y sobrantes **por separado**
(nunca neteados) en unidades y valorizados, duración de sesión, antigüedad promedio.

---

## 5. Flujo de estados objetivo

```
ACTIVA
  ├─ [escaneo OK] ─────────────→ VERIFICADA ✅
  └─ [no escaneada al cierre] ─→ PENDIENTE_RECONTEO
                                   ├─ [hallada] ─→ VERIFICADA ✅
                                   └─ [no hallada] ─→ EN_INVESTIGACION
                                                        └─→ EXTRAVIADA
                                                            (motivo + responsable + fecha)

ESCANEADA + estado "Entregada"  →  ENTREGADA_ERRONEA → revertir a ACTIVA
ESCANEADA + no existe en DB     →  FALTA_POR_INGRESAR → alta manual
```

---

## 6. Prioridad de trabajo sugerida

| # | Tarea | Impacto | Riesgo |
|---|---|---|---|
| 1 | Fix contador Extraviadas (§4.1) | Alto | Bajo |
| 2 | Snapshot / corte documental (§4.2) | Alto | Medio |
| 3 | Sesiones + operador (§4.5) | Alto | Medio |
| 4 | Reconteo (§4.3) | Medio | Bajo |
| 5 | Motivo obligatorio (§4.4) | Medio | Bajo |
| 6 | Separar Entregadas Sin Pago (§4.6) | Medio | Medio |
| 7 | Duplicados + métricas (§4.7, §4.8) | Bajo | Bajo |

---

## 7. ❓ Pendiente de confirmar (necesito ver el código)

- [ ] Stack: framework, backend, base de datos
- [ ] Estructura de tablas: `ordenes`, estados posibles, dónde se guarda el escaneo
- [ ] Cómo se calcula cada contador de los tabs
- [ ] ¿"Caducadas" está dentro de "Activas" o es un universo aparte?
- [ ] ¿El escaneo escribe directo en `ordenes` o en una tabla de auditoría?
- [ ] ¿Existe algún concepto de sesión hoy?
- [ ] ¿Hay valorización ($) por orden disponible?
- [ ] Qué genera el botón `Finalizar / Reporte`

---

## 8. Reportes requeridos por el usuario

Archivo: `reporte_auditoria_deposito.sql`

| # | Reporte | Query | Campo clave que necesita |
|---|---|---|---|
| 1 | Resumen ejecutivo | §1 | todos |
| 2 | Órdenes con código duplicado | §2 | `codigo` |
| 2B | Mismo cliente + mismo día | §2B | `cliente`, `fecha_ingreso` |
| 2C | Escaneos duplicados en sesión | §2C | tabla `escaneos_auditoria` |
| 3 | Sin avisar (+ prioridad por antigüedad) | §3 / §3B | **`fecha_aviso`** |
| 4 | Aging por tramos | §4 / §4B | `fecha_ingreso` |
| 5 | Valorización del depósito | §5 / §5B | `valor_declarado`, `monto_cobrar`, `pagado` |

### ⚠️ Definiciones que hay que fijar con el usuario
- **"Doble"** = ¿código repetido en DB, o mismo bulto ingresado 2 veces, o doble escaneo?
  Los tres casos están cubiertos, pero el reporte "oficial" debe elegir uno.
- **"Costo"** = valor de mercadería en custodia ≠ dinero pendiente de cobro. Reportar separado.
- **"Sin avisar"** = ¿nunca se avisó, o no se avisó en los últimos N días? (reaviso)

### Campos que probablemente falten en la DB
- `fecha_aviso` / tabla `avisos` (canal, fecha, resultado) → **sin esto no hay reporte 3**
- `valor_declarado` → sin esto no hay valorización
- `sesion_id` en escaneos → sin esto no se pueden separar auditorías

---

## 9. Bitácora de cambios

| Fecha | Cambio | Archivos tocados |
|---|---|---|
| 2026-08-17 | Creación del cerebro a partir de screenshot de UI | — |
| 2026-08-17 | Set de queries del reporte (dobles, sin avisar, aging, valorización) | `reporte_auditoria_deposito.sql` |
| 2026-08-17 | Prototipo HTML del reporte con datos sintéticos (850 órdenes, semilla 20260817) | `reporte_auditoria_prototipo.html` |
| 2026-08-17 | Versión final: estructura calcada del video + descarga de reporte | `auditoria_reportes.html` |
| 2026-09-04 | **Cambio de arquitectura**: registro de casos permanente + motor de fusión | `ESPEC_registro_de_casos.md`, `mockup_registro_casos.html` |

---

## 11. ⭐ ARQUITECTURA VIGENTE — Registro de casos (2026-09-04)

**Esto reemplaza el enfoque de "reportes por auditoría".** Ver `ESPEC_registro_de_casos.md`
para el detalle completo. Resumen de lo que no hay que romper:

### Dos capas separadas
| Capa | Qué es | Vida |
|---|---|---|
| **Auditoría** | Evento: fotografía (snapshot) + escaneos de esa sesión | Inmutable al cerrar |
| **Caso** | Problema sobre una orden, con su historia y acciones | Permanente hasta resolverse |

Una auditoría **NO genera lista nueva**: alimenta el registro que ya existe.

### Regla de fusión (el corazón del sistema)
| Situación | Resultado |
|---|---|
| Hallazgo nuevo | Crea caso |
| Ya existe y está abierto | **NO crea.** `veces_detectado++`, actualiza última detección |
| Caso abierto que ya no aparece | Auto-cierre: "no reapareció" |
| Caso cerrado que reaparece | Reabre marcado `reincidente` |

### Invariantes que NO se pueden romper
1. **Dedup a nivel base:** `UNIQUE (orden_id, tipo) WHERE estado NOT IN ('RESUELTO','ASUMIDO')`.
   Índice único parcial. Si la app falla, la base lo impide igual.
2. **La clave es `orden_id`, NUNCA `orden_codigo`.** Un tipo de caso es "código duplicado":
   usar el código como identidad fusionaría dos órdenes distintas en un solo caso.
3. **Auto-cierre solo dentro del alcance.** Si se auditó solo la zona A, los casos de zona B
   no se pueden dar por resueltos. Sin esta condición una auditoría parcial cierra en falso
   media lista. Verificado en el mockup: auditoría de zona A cerró 0 casos de zona B.
4. **Los hallazgos se calculan contra el snapshot, nunca contra la tabla viva.**
5. **Ningún caso pasa a `ASUMIDO` sin motivo y sin responsable.**
6. **Los movimientos ocurridos durante la auditoría no generan casos.**

### Verificación del motor (6 auditorías simuladas)
```
AUD-0615 TOTAL | nuevos 46 | ya estaban  0 | reincid 0 | resueltos  0
AUD-0817 TOTAL | nuevos 11 | ya estaban 26 | reincid 0 | resueltos  9
AUD-0904 ZONA A| nuevos 11 | ya estaban 17 | reincid 0 | resueltos  3  ← no tocó zona B
AUD-1010 TOTAL | nuevos 10 | ya estaban 28 | reincid 1 | resueltos 17
AUD-1110 TOTAL | nuevos  9 | ya estaban 27 | reincid 2 | resueltos 12
AUD-1210 TOTAL | nuevos  9 | ya estaban 24 | reincid 4 | resueltos 14
→ 96 casos totales, 37 abiertos, 0 duplicados, 19 crónicos, 7 reincidentes
```

### Orden de implementación (no se puede reordenar)
`Fase 0` campos faltantes → `Fase 1` sesión + snapshot → `Fase 2` motor de fusión →
`Fase 3` pantalla → `Fase 4` reportes → `Fase 5` conteo cíclico.

### ⚠️ La trampa de la primera corrida
La primera auditoría con el motor activo crea **cientos de casos de golpe**. Una lista de
400 casos el día uno es una lista que nadie mira. Mitigación: marcarla como *línea base*,
ordenar por severidad y no por fecha, activar `SIN_AVISO` y `PERMANENCIA` recién en la
segunda corrida, y no mostrar "crónicos" hasta que haya una segunda auditoría.

> Los archivos `reporte_auditoria_prototipo.html` y `reporte_auditoria_v2.html` quedaron
> obsoletos y fueron eliminados. El vigente es `auditoria_reportes.html`.

### ⚠️ Estructura del layout (esto se había hecho mal en la v2)
El sistema usa **UN panel blanco único** que contiene la barra de tabs Y el contenido.
NO son tarjetas sueltas flotando sobre el fondo.

```
fondo #F4F7FB
└── contenedor (max-width 1180)
    ├── h1 + subtítulo         ← FUERA del panel, sobre el fondo
    └── .panel (blanco, radio 14px, borde #EAEEF4)
        ├── .tabbar            ← DENTRO del panel, con borde inferior
        └── .cuerpo (pad 22px)
            ├── .sec-h         ← título indigo + subtítulo + botones a la derecha
            └── .marco         ← cada tabla en su propio marco redondeado
```

- Las tablas van en **marco propio** (borde + radio 11px), cabecera `#F8FAFC` sticky.
- Título de sección: indigo `#4F46E5` bold 16px. Cambia de color según semántica
  (violeta en Caducadas, rojo en faltantes, ámbar en errores).
- Nombre de cliente en indigo en listados generales; oscuro + `COMUN` gris en los operativos.

### Descarga de reporte (v2)
- Botón **Descargar reporte** en la barra de corte → abre vista previa en overlay.
- Dos versiones: **ejecutivo** (~2 páginas, listados recortados) y **completo** (listados extendidos).
- Salidas: **PDF** vía `window.print()` con `@media print` dedicado, y **Excel** en formato
  SpreadsheetML 2003 (`.xls`, sin librerías externas) con 7 hojas:
  Resumen · Antiguedad · Duplicadas · Mismo cliente mismo dia · Sin avisar · Por cliente · Censo completo.
- La sección **Hallazgos** se genera sola con `hallazgos()`: cruza los datos y redacta las
  conclusiones en texto. Ese cruce (sin aviso × antigüedad) es el que explica el estancamiento.
- El documento cierra con líneas de firma (Responsable de depósito / Auditor) — la auditoría
  necesita conformidad de dos personas distintas, ver §4.4 sobre separación de funciones.

---

## 10. Sistema de diseño del proyecto (extraído del video)

**Usar SIEMPRE estos tokens al crear pantallas nuevas.**

```css
--bg:#F3F6FA          /* fondo de página, azul-gris muy claro */
--card:#FFFFFF        /* tarjetas, radio 12px, sombra 0 1px 2px rgba(27,36,52,.04) */
--borde:#E9EDF4
--titulo:#1B2434      /* títulos, peso 700-800 */
--texto:#3D4759
--suave:#8A94A6       /* subtítulos y labels */

--violeta:#8A17D9     /* primario: tab activa, botón de acción */
--indigo:#4F46E5      /* códigos de orden en tablas */
--verde:#19B24A       /* botón Excel */
--rojo:#DC2626        /* Faltan por Escanear, sin avisar */
--ambar:#D97706       /* Entregada Errónea */
--naranja:#EA7C1B     /* Regresar a Depósito */
--magenta:#D6336C     /* columna de días */
--navy:#1E2A38        /* botones oscuros: Cámara del móvil, Finalizar/Reporte */
```

- **Tipografía:** Plus Jakarta Sans (títulos 700/800) + JetBrains Mono (códigos, días, montos).
- **Tabs:** icono outline + label + badge con contador. Activa = color violeta + subrayado 2.5px.
  El color de la tab activa cambia según la semántica de la sección (Sobrantes = naranja).
- **Tablas:** cabecera `#F8FAFC` sticky, código en mono bold indigo, días en mono bold magenta,
  filas con borde inferior `#F1F4F8`.
- **Cabecera de tarjeta:** título coloreado + subtítulo explicativo del mismo tono más claro
  + botones alineados a la derecha (Excel verde siempre último).
- **Patrón de acción en lote:** checkbox por fila → `<select>` de acción → botón violeta
  "Ejecutar Acción (n)" deshabilitado si n=0. Replicado en la vista "Sin avisar".
- **Estado vacío:** ícono lupa gris centrado + texto en gris.

### Notas del prototipo
- La "franja de sedimentación" es el elemento central: barra proporcional por tramo de
  permanencia, clickeable, filtra todas las tablas.
- Vistas implementadas: Antigüedad, Duplicadas (2 criterios), Sin avisar, Por cliente.
- Para conectarlo a la DB real: reemplazar `generarDatos()` por el fetch al endpoint.
  El resto del código consume el array `ORDENES` con esta forma:
  `{codigo, cliente, dias, avisoDias, valor, cobrar, pagado}` + campos derivados
  (`tramo`, `ingreso`, `ingresoTxt`) que calcula el propio script.
